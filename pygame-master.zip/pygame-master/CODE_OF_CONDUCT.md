

welcome to our humble (and slightly strange) little part of the World Wide Web. 
Let me give you a quick introduction about what you've stumbled upon here.

pygame (the library) is a Free and Open Source python programming language library
for making multimedia applications like games.

pygame.org (the website) welcomes all Python game, art, music, sound, 
video and multimedia projects. Once you have finished getting started you could
add a new project or learn about pygame by reading the docs. For more information
on what is happening in the pygame world see the community dashboard web page,
which lists many things like our projects we are working on, news (our blog with rss),
twitter, reddit (forum), stackoverflow (Q&A), Bitbucket (development), irc(chat),
mailinglist (we love writing electronic mail to each other) and other various bits
and pieces about pygame from around the internets.

pygame (the community) is a small volunteer group of creative humans who ♥ making things
(there may also be a few cats, several koalas, dozens of doggos,
3.14 gnomes, and 42 robots who also tinker amongst us). We respect each other, and
follow the [Python community code of conduct](https://www.python.org/psf/codeofconduct/),
whilst we help each other make interesting things.

Enjoy yourself whilst looking around. We look forward to your creations.


Best humanly possible wishes and extra toasty warm regards,
pygame

ps. We spell colour without the u (sorry), and we always spell pygame with lower case letters.
Also, please do excuse the mess - we're doing some renovations around here you see.
